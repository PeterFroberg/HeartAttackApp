package com.example.peter.heartattackapp;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}